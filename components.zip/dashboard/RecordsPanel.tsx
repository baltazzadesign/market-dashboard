"use client";
import { useEffect, useMemo, useState } from "react";
import { type MarketRow, type MarketEvent, formatNumber as fmt, valueClass, sourceLabel, rowsCsv, eventsCsv } from "@/lib/balta-model";
import { Icon } from "./Icon";
export type RecordView = "records" | "signals";

function sessionLabel(session: MarketRow["session"]) {
  return ({
    REGULAR: "정규장",
    AFTER_HOURS_CLOSE: "장후종가",
    OLD_AFTER_HOURS_SINGLE_PRICE: "시간외단일가",
    KRX_AFTER_MARKET: "애프터마켓",
    CLOSED: "장마감",
    UNKNOWN: "세션 미확인",
  } as Record<MarketRow["session"], string>)[session] ?? session;
}
function breadthAvailable(row: MarketRow) {
  return ["LIVE", "FALLBACK"].includes(row.breadthSource);
}
export function downloadCsv(filename: string, content: string) {
  const url = URL.createObjectURL(new Blob([content], { type: "text/csv;charset=utf-8;" }));
  const anchor = document.createElement("a"); anchor.href = url; anchor.download = filename; anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export default function RecordsPanel({ rows, events, date, selectedMinute, onSelect, view, onViewChange }: {
  rows: MarketRow[]; events: MarketEvent[]; date: string; selectedMinute: number | null;
  onSelect: (minute: number) => void; view: RecordView; onViewChange: (view: RecordView) => void;
}) {
  const [query, setQuery] = useState(""), [level, setLevel] = useState("전체"), [signalKind, setSignalKind] = useState("전체"), [newest, setNewest] = useState(true), [page, setPage] = useState(0);
  useEffect(() => setPage(0), [query, level, signalKind, date, view, newest]);
  const filteredRows = useMemo(() => rows.filter(row => [row.time, sourceLabel(row.flowSource), ...events.filter(e => e.minute === row.minute).map(e => e.label)].join(" ").toLowerCase().includes(query.toLowerCase())), [rows, events, query]);
  const filteredEvents = useMemo(() => events.filter(event => {
    const turning = /^(PIVOT_|BREADTH_REVERSAL_|FLOW_REVERSAL_|INDEX_FLOW_DIVERGENCE_|INTRADAY_(HIGH|LOW)_TURN)/.test(event.type);
    return (level === "전체" || event.level === level)
      && (signalKind === "전체" || (signalKind === "변곡" && turning) || (signalKind === "기타" && !turning))
      && [event.time, event.label, event.message, event.source].join(" ").toLowerCase().includes(query.toLowerCase());
  }), [events, query, level, signalKind]);
  const items = useMemo(() => (view === "records" ? filteredRows : filteredEvents).slice().sort((a, b) => newest ? b.minute - a.minute : a.minute - b.minute), [view, filteredRows, filteredEvents, newest]);
  const maxPage = Math.max(0, Math.ceil(items.length / 20) - 1), currentPage = Math.min(page, maxPage);
  const visible = items.slice(currentPage * 20, currentPage * 20 + 20);
  function exportFiltered() { downloadCsv("baltatool-" + date + "-" + view + ".csv", view === "records" ? rowsCsv(items as MarketRow[]) : eventsCsv(items as MarketEvent[])); }
  return <section id="records" className="panel" style={{ scrollMarginTop: 24 }} aria-labelledby="records-heading">
    <div className="panel-header"><div><h2 className="panel-title" id="records-heading"><Icon name="table" size={17}/>기록 탐색</h2><p className="panel-subtitle">{date || "선택 날짜"} · 시간 선택 시 차트 이동</p></div><div className="segmented" aria-label="기록 종류"><button className={view === "signals" ? "active" : ""} aria-pressed={view === "signals"} onClick={() => onViewChange("signals")}>신호 {events.length}</button><button className={view === "records" ? "active" : ""} aria-pressed={view === "records"} onClick={() => onViewChange("records")}>전체 기록 {rows.length}</button></div></div>
    <div className="table-tools"><label className="search-input"><Icon name="search" size={16}/><input value={query} onChange={event => setQuery(event.target.value)} placeholder={view === "records" ? "시간·수급 상태 검색" : "시간·신호·내용 검색"} aria-label="기록 검색"/></label>{view === "signals" && <><select className="filter-select" aria-label="신호 종류" value={signalKind} onChange={e => setSignalKind(e.target.value)}><option value="전체">모든 신호</option><option value="변곡">변곡점만</option><option value="기타">기타 신호</option></select><select className="filter-select" aria-label="신호 강도" value={level} onChange={e => setLevel(e.target.value)}><option value="전체">모든 강도</option><option value="강">강한 신호</option><option value="중">중간 신호</option><option value="약">약한 신호</option></select></>}<button className="button small" onClick={() => setNewest(v => !v)}><Icon name={newest ? "down" : "up"} size={14}/>{newest ? "최신순" : "시간순"}</button><button className="button small" disabled={!items.length} onClick={exportFiltered} title="현재 검색·필터에 해당하는 모든 기록 다운로드"><Icon name="download" size={15}/>CSV</button></div>
    {!visible.length ? <div className="empty-state compact"><Icon name="search" size={24}/><strong>{query || level !== "전체" ? "조건에 맞는 기록이 없어요" : view === "signals" ? "감지된 신호가 없어요" : "저장된 기록이 없어요"}</strong><p>{query || level !== "전체" ? "검색어나 강도 필터를 바꿔보세요." : "데이터가 들어오면 이곳에서 확인할 수 있어요."}</p></div> :
      <div className="table-scroll" role="region" aria-label={view === "records" ? "시간별 시장 기록" : "시장 신호 기록"} tabIndex={0}><table className="data-table"><caption className="sr-only">{date} {view === "records" ? "시간별 지표와 투자자 수급. 수급 단위는 억원." : "발생 시간별 시장 신호"}</caption>
        {view === "records" ? <><thead><tr>{["시간","세션","시장 폭","시장점수","상승","하락","KOSPI","KOSDAQ","외국인","기관","개인","수급 상태"].map(label => <th key={label} scope="col">{label}</th>)}</tr></thead><tbody>{(visible as MarketRow[]).map(row => { const hasBreadth=breadthAvailable(row); return <tr key={row.time} className={selectedMinute === row.minute ? "selected" : ""}><td><button className="time-button num" onClick={() => onSelect(row.minute)} aria-label={row.time + " 차트로 이동"}>{row.time}</button></td><td><span className="tag">{sessionLabel(row.session)}</span></td><td className={"num " + (hasBreadth ? valueClass(row.diff) : "")}>{hasBreadth ? fmt(row.diff, 0, true) : "—"}</td><td className={"num " + (hasBreadth ? valueClass(row.marketScore) : "")}>{hasBreadth ? fmt(row.marketScore, 0, true) : "—"}</td><td className={"num " + (hasBreadth ? "positive" : "")}>{hasBreadth ? fmt(row.up) : "—"}</td><td className={"num " + (hasBreadth ? "negative" : "")}>{hasBreadth ? fmt(row.down) : "—"}</td><td className="num">{fmt(row.kospi, 2)}</td><td className="num">{fmt(row.kosdaq, 2)}</td><td className={"num " + valueClass(row.foreignFlow)}>{fmt(row.foreignFlow, 0, true)}</td><td className={"num " + valueClass(row.instFlow)}>{fmt(row.instFlow, 0, true)}</td><td className={"num " + valueClass(row.indivFlow)}>{fmt(row.indivFlow, 0, true)}</td><td><span className={"tag" + (row.flowSource !== "LIVE" ? " strong" : "")}>{sourceLabel(row.flowSource)}</span></td></tr>; })}</tbody></> :
          <><thead><tr>{["시간","강도","신호","내용","출처"].map(label => <th key={label} scope="col">{label}</th>)}</tr></thead><tbody>{(visible as MarketEvent[]).map(event => <tr key={event.id} className={selectedMinute === event.minute ? "selected" : ""}><td><button className="time-button num" onClick={() => onSelect(event.minute)} aria-label={event.time + " 신호를 차트에서 확인"}>{event.time}</button></td><td><span className={"tag" + (event.level === "강" ? " strong" : "")}>{event.level}</span></td><td className={"text-cell " + (event.direction === "up" ? "positive" : event.direction === "down" ? "negative" : "")}>{event.label}</td><td className="text-cell muted">{event.message}</td><td><span className="tag">{event.source}</span></td></tr>)}</tbody></>}
      </table></div>}
    <div className="pagination"><span>{items.length ? (currentPage * 20 + 1) + "–" + Math.min((currentPage + 1) * 20, items.length) + " / " + items.length + "개" : "0개"}</span><div className="toolbar"><button className="button small icon" aria-label="이전 페이지" disabled={currentPage === 0} onClick={() => setPage(currentPage - 1)}><Icon name="left" size={15}/></button><span className="num">{currentPage + 1} / {maxPage + 1}</span><button className="button small icon" aria-label="다음 페이지" disabled={currentPage >= maxPage} onClick={() => setPage(currentPage + 1)}><Icon name="right" size={15}/></button></div></div>
  </section>;
}
