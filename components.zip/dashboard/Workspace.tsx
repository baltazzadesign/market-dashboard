"use client";
import { BaltaJungyongHeaderLink } from './BaltaJungyongHeaderLink';
import Link from "next/link";
import dynamic from "next/dynamic";
import { useEffect, useMemo, useRef, useState } from "react";
import { OPEN_MINUTE, CLOSE_MINUTE, type MarketEvent, type MarketRow, kstParts, isValidDate, moveDate, minuteLabel, formatNumber, dataStatus, rowsCsv, sourceLabel, breadthLabel } from "@/lib/balta-model";
import { buildMarketEvents } from "@/lib/balta-signals";
import PanelLayout from "./PanelLayout";
import ComparisonReport from "./ComparisonReport";
import Diagnostics from "./Diagnostics";
import { Brand, Icon } from "./Icon";
import { useMarketFeed } from "./useMarketFeed";
import { Modal } from "./Modal";
import { Metrics, FlowPanel, SignalPanel, SessionSummary } from "./Insights";
import RecordsPanel, { downloadCsv, type RecordView } from "./RecordsPanel";
import { chartNames as chartLabels, type ChartKind, type Domain } from "./chart-model";
import SectorHeatmap from "./SectorHeatmap";
import MarketPulsePanel, { useMarketPulse } from "./MarketPulse";
import InvestmentDisclaimer from "./InvestmentDisclaimer";
import MarketMovers from "./MarketMovers";

const MarketChart = dynamic(() => import("./MarketCharts"), { ssr: false, loading: () => <div className="chart-loading"><Icon name="refresh" className="spin"/>차트 준비 중</div> });
const chartKeys = Object.keys(chartLabels) as ChartKind[];
type Settings = { autoRefresh: boolean; markers: boolean; compare: boolean; autoScale: boolean; notifications: boolean };
const defaults: Settings = { autoRefresh:true,markers:true,compare:true,autoScale:true,notifications:false };

function fit(start:number,end:number):Domain {
  const minWindow=5,total=CLOSE_MINUTE-OPEN_MINUTE;
  let left=Math.round(Math.min(start,end)),right=Math.round(Math.max(start,end));
  const width=Math.max(minWindow,right-left);
  if(width>=total)return [OPEN_MINUTE,CLOSE_MINUTE];
  left=Math.max(OPEN_MINUTE,Math.min(CLOSE_MINUTE-width,left));
  right=left+width;
  return [left,right];
}

function LiveClock() {
  const [clock,setClock] = useState("");
  useEffect(()=>{
    const tick=()=>setClock(kstParts().clock);
    tick();
    const id=window.setInterval(tick,15000);
    return()=>window.clearInterval(id);
  },[]);
  return <span className="clock-label num">{clock||"—"} KST</span>;
}

export default function Workspace({ mode }: { mode:"overview" | "daily" }) {
  const [date,setDate] = useState(""),[today,setToday] = useState(""),[now,setNow] = useState<Date | null>(null),[followToday,setFollowToday] = useState(true);
  const [settings,setSettings] = useState<Settings>(defaults),[settingsLoaded,setSettingsLoaded] = useState(false);
  const [kind,setKind] = useState<ChartKind>(mode==="overview"?"kospi":"flow"),[range,setRange] = useState("all"),[customDomain,setCustomDomain] = useState<Domain>([OPEN_MINUTE,CLOSE_MINUTE]);
  const [selectedMinute,setSelectedMinute] = useState<number | null>(null),[modal,setModal] = useState<"settings" | "guide" | "chart" | "board" | "command" | "more" | null>(null);
  const [hoverMinute,setHoverMinute] = useState<number | null>(null),[expandedKind,setExpandedKind] = useState<ChartKind>("flow");
  const [tableView,setTableView] = useState<RecordView>(mode==="daily"?"records":"signals");
  const [returnToModal,setReturnToModal] = useState<"board" | "command" | null>(null);
  const [boardColumns,setBoardColumns] = useState<2|3>(3);
  const [toast,setToast] = useState(""),[loggingOut,setLoggingOut] = useState(false);
  const dateInitialized = useRef(false);
  const seen = useRef<{date:string;ids:Set<string>;armed:boolean}>({date:"",ids:new Set(),armed:false});
  useEffect(()=>{
    const tick=()=>{const dateNow=new Date(),parts=kstParts(dateNow);setToday(parts.date);setNow(dateNow);if(!dateInitialized.current){dateInitialized.current=true;const requested=new URLSearchParams(window.location.search).get("date");if(requested&&isValidDate(requested)&&requested<=parts.date){setDate(requested);setFollowToday(requested===parts.date);return;}}if(followToday)setDate(parts.date);};
    tick();const id=window.setInterval(tick,60000);return()=>window.clearInterval(id);
  },[followToday]);
  useEffect(()=>{
    try {
      const saved=JSON.parse(localStorage.getItem("baltatool.preferences.v2")??"{}") as Record<string,unknown>;
      setSettings(old=>({...old,...Object.fromEntries(Object.keys(defaults).filter(key=>typeof saved[key]==="boolean").map(key=>[key,saved[key]])),notifications: saved.notifications===true && "Notification" in window && Notification.permission==="granted"}));
    } catch {}
    setSettingsLoaded(true);
  },[]);
  useEffect(()=>{if(settingsLoaded){try{localStorage.setItem("baltatool.preferences.v2",JSON.stringify(settings));}catch{}}},[settings,settingsLoaded]);
  useEffect(()=>{setSelectedMinute(null);setHoverMinute(null);setRange("all");},[date]);
  useEffect(()=>{if(!toast)return;const id=setTimeout(()=>setToast(""),5500);return()=>clearTimeout(id);},[toast]);
  const feed=useMarketFeed(date,mode==="overview"&&date===today,settings.autoRefresh);
  const rows=feed.rows,last=rows.at(-1);
  const { pulse, sectorStatus } = useMarketPulse(rows, date, feed.fetchedAt);
  // 자동 신호/정규장 리포트는 기존 정규장 데이터로만 계산합니다.
  // 상단 지표와 우측 브리핑/수급은 현재 세션의 최신 기록(last)을 사용합니다.
  const signalRows=useMemo(()=>rows.filter(row=>row.session==="REGULAR"),[rows]);
  const events=useMemo(()=>buildMarketEvents(signalRows),[signalRows]);
  const status=useMemo(()=>dataStatus(last,date,feed.error,now??new Date(0)),[last,date,feed.error,now]);
  const domain=useMemo<Domain>(()=>range==="custom"?customDomain:range==="all"?[OPEN_MINUTE,CLOSE_MINUTE]:fit((last?.minute??CLOSE_MINUTE)-Number(range),last?.minute??CLOSE_MINUTE),[range,customDomain,last?.minute]);
  const overviewKinds: ChartKind[] = ["breadth", "ratio"];
  const comparisonKinds: ChartKind[] = mode === "daily" ? ["kospi", "kosdaq", "score", "accel"] : ["kospi", "kosdaq"];
  useEffect(()=>{
    if(!date||!rows.length)return;
    const state=seen.current;
    if(!settings.notifications||date!==today||feed.loading||feed.error||feed.warning){
      seen.current={date,ids:new Set(events.map(e=>e.id)),armed:false};return;
    }
    if(state.date!==date||!state.armed){seen.current={date,ids:new Set(events.map(e=>e.id)),armed:true};return;}
    const minute=kstParts().minute;
    const latest=events.find(e=>e.level==="강"&&!state.ids.has(e.id)&&minute>=e.minute&&minute-e.minute<=3);
    events.forEach(event=>state.ids.add(event.id));
    if(latest){
      setToast(latest.time+" · "+latest.label);
      if("Notification" in window&&Notification.permission==="granted"){
        try{new Notification("baltatool · "+latest.label,{body:latest.time+" / "+latest.message,tag:latest.id});}catch{}
      }
    }
  },[date,today,rows.length,events,settings.notifications,feed.loading,feed.error,feed.warning]);
  function changeDate(value:string){if(!isValidDate(value)||value>today)return;setFollowToday(value===today);setDate(value);}
  function focusMinute(minute:number){window.dispatchEvent(new CustomEvent("balta-reveal-panel",{detail:"main-chart"}));setSelectedMinute(minute);setCustomDomain(fit(minute-30,minute+30));setRange("custom");document.getElementById("market-charts")?.scrollIntoView({behavior:window.matchMedia("(prefers-reduced-motion: reduce)").matches?"auto":"smooth",block:"start"});}
  function showRecords(){
    if(mode==="overview"){window.location.assign("/daily#records");return;}
    window.dispatchEvent(new CustomEvent("balta-reveal-panel",{detail:"records"}));
    setTableView("signals");
    document.getElementById("records")?.scrollIntoView({behavior:"smooth",block:"start"});
  }
  function changeDomain(value:Domain){setRange("custom");setCustomDomain(fit(...value));}
  function resetCharts(){setRange("all");setSelectedMinute(null);setHoverMinute(null);}
  function latestCharts(){setRange("60");setSelectedMinute(null);setHoverMinute(null);}
  function openChart(key:ChartKind){setReturnToModal(modal==="board"||modal==="command"?modal:null);setExpandedKind(key);setHoverMinute(null);setModal("chart");}
  function exportDay(){if(!rows.length)return;downloadCsv("baltatool-"+date+".csv",rowsCsv(rows));setToast(date+" 전체 기록을 CSV로 저장했어요.");}
  async function toggleNotifications(enabled:boolean){
    if(!enabled){setSettings(old=>({...old,notifications:false}));return;}
    if(!("Notification" in window)){setToast("이 브라우저에서는 데스크톱 알림을 지원하지 않아요.");return;}
    try{const permission=await Notification.requestPermission();setSettings(old=>({...old,notifications:permission==="granted"}));if(permission!=="granted")setToast("브라우저 알림 권한을 허용해야 사용할 수 있어요.");}catch{setToast("브라우저 알림 설정을 확인해 주세요.");}
  }
  async function logout(){
    setLoggingOut(true);
    try{const response=await fetch("/api/auth/logout",{method:"POST"});if(!response.ok)throw new Error();window.location.assign("/login");}
    catch{setLoggingOut(false);setToast("로그아웃하지 못했어요. 다시 시도해 주세요.");}
  }
  const chartProps={rows,kind,domain,selectedMinute,events,showMarkers:settings.markers,autoScale:settings.autoScale,onDomainChange:changeDomain,hoverMinute,onHoverMinute:setHoverMinute,onReset:resetCharts,onLatest:latestCharts,refreshing:feed.refreshing,dataCaption:feed.warning?"수집 상태 확인":status.tone?status.label:settings.autoRefresh?"60초 자동 갱신":"자동 갱신 일시정지"};
  function comparisonChart(key:ChartKind){return <section className="panel comparison-panel" key={key}><div className="panel-header"><h2 className="panel-title">{chartLabels[key]}</h2><span className="panel-subtitle">{date}</span></div><MarketChart {...chartProps} kind={key} compact onExpand={()=>openChart(key)}/></section>;}
  function ranges(){return <div className="segmented" aria-label="차트 시간 범위">{[{value:"all",label:"전체"},{value:"60",label:"1시간"},{value:"30",label:"30분"}].map(item=><button key={item.value} className={range===item.value?"active":""} aria-pressed={range===item.value} onClick={()=>{setRange(item.value);setSelectedMinute(null);}}>{item.label}</button>)}</div>;}
  function mainChartPanel(){return <section className="panel overview-main-chart" id="market-charts" style={{scrollMarginTop:24}} aria-labelledby="chart-heading"><div className="panel-header"><div><h2 className="panel-title" id="chart-heading">장중 흐름</h2><p className="panel-subtitle">{date||"선택 날짜"} · {rows.length}개 기록{selectedMinute!==null?" · "+minuteLabel(selectedMinute)+" 선택":""}</p></div><div className="toolbar">{ranges()}<button className="button icon small" onClick={()=>openChart(kind)} aria-label="차트 크게 보기" disabled={!rows.length}><Icon name="expand" size={16}/></button></div></div>
    <div className="chart-tabs" aria-label="차트 지표">{(mode==="overview"?(["kospi","kosdaq"] as ChartKind[]):chartKeys).map(key=><button key={key} className={"chart-tab"+(kind===key?" active":"")} aria-pressed={kind===key} onClick={()=>setKind(key)}>{chartLabels[key]}</button>)}</div>
    {feed.loading?<div className="chart-loading"><Icon name="refresh" className="spin"/>시장 기록을 불러오는 중</div>:!rows.length?<div className="empty-state" style={{minHeight:320}}><Icon name={feed.error?"warning":"chart"} size={34}/><strong>{feed.error?"시장 기록을 불러오지 못했어요":"선택한 날짜의 기록이 없어요"}</strong><p>{feed.error?"데이터 연결을 확인한 뒤 다시 시도해 주세요.":"주말·휴장일이거나 아직 기록이 수집되지 않았을 수 있어요. 다른 날짜를 선택해 보세요."}</p><button className="button" onClick={()=>void feed.refresh(true)} disabled={feed.refreshing}><Icon name="refresh" size={15}/>다시 조회</button></div>:<MarketChart {...chartProps}/>} 
    <div className="chart-footer"><span className="num">{minuteLabel(domain[0])}–{minuteLabel(domain[1])}</span><span className="desktop-hint">5분까지 확대 · 모든 차트 시간축 연동</span><button className="button ghost small" onClick={()=>{setRange("all");setSelectedMinute(null);}}>확대 초기화</button></div>
  </section>;}
  const overviewStats = [
    {label:"시장 폭", value:last?.diff, unit:"개", signed:true, tone:(last?.diff??0)>0?"positive":(last?.diff??0)<0?"negative":""},
    {label:"상승 종목", value:last?.up, unit:"개", signed:false, tone:"positive"},
    {label:"하락 종목", value:last?.down, unit:"개", signed:false, tone:"negative"},
    {label:"외국인", value:last?.foreignFlow, unit:"억", signed:true, tone:"flow-blue"},
    {label:"기관", value:last?.instFlow, unit:"억", signed:true, tone:"flow-red"},
    {label:"개인", value:last?.indivFlow, unit:"억", signed:true, tone:"flow-yellow"},
  ];
  const pulseMiniScore = Math.max(0, Math.min(100, pulse.score ?? 50));
  const pulseMiniAngle = Math.PI * (1 - pulseMiniScore / 100);
  const pulseMiniX = 65 + 48 * Math.cos(pulseMiniAngle);
  const pulseMiniY = 61 - 48 * Math.sin(pulseMiniAngle);
  const pulseMiniLabels = ["수급", "시장폭", "거래대금", "변동성", "추세"];
  return <div className={"workspace workspace-"+mode}>
    <a className="skip-link" href="#main-content">본문으로 이동</a>
    <aside className="sidebar" aria-label="주 메뉴"><Link href="/" aria-label="발타툴 대시보드"><Brand/></Link><div className="workspace-label">MARKET</div><nav className="nav-list"><Link href="/" className={"nav-link"+(mode==="overview"?" active":"")} aria-current={mode==="overview"?"page":undefined} title="시장 대시보드"><Icon name="grid"/><span className="nav-label">시장 대시보드</span></Link><Link href="/daily" className={"nav-link"+(mode==="daily"?" active":"")} aria-current={mode==="daily"?"page":undefined} title="일별 분석"><Icon name="chart"/><span className="nav-label">일별 분석</span></Link><Link href="/history" className="nav-link" title="시장 캘린더 · 월간 평가"><Icon name="calendar"/><span className="nav-label">시장 캘린더</span></Link><Link href={"/replay?date="+date} className="nav-link"><Icon name="chart"/><span className="nav-label">시장 복기</span></Link><Link href="/research" className="nav-link"><Icon name="layers"/><span className="nav-label">시장 리서치</span></Link><button className="nav-link" onClick={showRecords} title="신호 기록"><Icon name="bell"/><span className="nav-label">신호 기록</span><span className="nav-end tag">{events.length}</span></button></nav><div className="workspace-label reading-label">BALTA ARCHIVE</div><nav className="nav-list reading-nav" aria-label="발타 아카이브"><a href="/baltagyeong.html" className="nav-link"><Icon name="book"/><span className="nav-label">발타경</span></a><Link href="/balta-jungyong" className="nav-link"><Icon name="balance"/><span className="nav-label">발타 중용</span></Link></nav><a href="/baltagyeong.html" className="sidebar-archive-card" aria-label="발타경 읽기"><span className="sidebar-archive-kicker">BALTA PRINCIPLE</span><strong>시장을 읽고,<br/>원칙으로 돌아간다.</strong><span className="sidebar-archive-meta">발타경 · 발타 중용 <Icon name="right" size={12}/></span></a><div className="sidebar-bottom"><button className="nav-link" onClick={()=>setModal("guide")} title="지표 가이드"><Icon name="help"/><span className="nav-label">지표 가이드</span></button><button className="nav-link" onClick={()=>setModal("settings")} title="화면 설정"><Icon name="settings"/><span className="nav-label">화면 설정</span></button><button className="nav-link" onClick={logout} disabled={loggingOut} title="로그아웃"><Icon name="logout"/><span className="nav-label">{loggingOut?"로그아웃 중":"로그아웃"}</span></button><div className="sidebar-note"><Icon name="layers"/><span><strong>KR MARKET</strong>KOSPI · KOSDAQ</span></div></div></aside>
    <header className="topbar dashboard-topbar mockup-topnav">
      <div className="mobile-brand"><Link href="/"><Brand/></Link></div>
      <div className="topnav-left">
        <Link href="/" className="topnav-brand" aria-label="발타툴 홈"><Brand/></Link>
        <nav className="topnav-main" aria-label="주요 메뉴">
          <Link href="/" className={mode==="overview"?"active":""}>대시보드</Link>
          <Link href="/flow">시장 수급</Link>
          <button onClick={()=>{setKind("breadth");document.getElementById("market-charts")?.scrollIntoView({behavior:"smooth",block:"start"});}}>시장폭</button>
          <a href="#market-pulse">Market Pulse</a>
          <Link href={"/research?date="+date}>섹터 분석</Link>
          <Link href={"/research?date="+date}>종목 스캐너</Link>
          <Link href="/history">캘린더</Link>
        </nav>
      </div>
      <div className="topnav-right">
        <Link className="topnav-search" href={"/research?date="+date} aria-label="시장 리서치 검색"><Icon name="search" size={15}/><span>종목·메모·시장 리서치</span></Link>
        <nav className="topbar-reading-links" aria-label="발타 문서"><a href="/baltagyeong.html" className="reading-link" data-baltagyeong-link="true" title="발타경 읽기"><Icon name="book" size={16}/><span>발타경</span></a><BaltaJungyongHeaderLink /></nav>
        <LiveClock/>
        <span className={"status "+status.tone}><span className="status-dot"/>{feed.loading?"불러오는 중":status.label}</span>
        <button className="button ghost icon topbar-settings" aria-label="화면 설정" onClick={()=>setModal("settings")}><Icon name="settings"/></button>
        <button className="button ghost icon mobile-menu-trigger" aria-label="전체 메뉴" onClick={()=>setModal("more")}><Icon name="layers"/></button>
      </div>
    </header>
    <main id="main-content" className="main-content">
      <div className="page-heading dashboard-heading mockup-hero">
        <div className="dashboard-heading-copy">
          <span className="dashboard-kicker">BALTA MARKET INTELLIGENCE</span>
          <h1>{mode==="overview"?<><span>시장을 읽는</span><strong>발바닥의 감각</strong></>:"일별 분석"}</h1>
          <p>{mode==="overview"?"데이터로 더 나은 판단을, 발타툴과 함께.":"시간대별 흐름과 주요 신호를 다시 살펴보세요."}</p>
          {mode==="overview"&&<span className="hero-english">GOOD DATA. BETTER DECISIONS.</span>}
        </div>
        <div className="dashboard-hero-signature" aria-hidden="true"><span>市場</span><strong>흔들리지 않는 시선이<br/>기회를 만든다.</strong></div>
        {mode==="daily"&&<div className="toolbar hero-toolbar"><button className="button icon" aria-label="이전 날짜" disabled={!date} onClick={()=>changeDate(moveDate(date,-1))}><Icon name="left" size={16}/></button><label className="date-control"><Icon name="calendar" size={16}/><span className="sr-only">조회 날짜</span><input type="date" value={date} max={today||undefined} onChange={e=>changeDate(e.target.value)} /></label><button className="button icon" aria-label="다음 날짜" disabled={!date||date>=today} onClick={()=>changeDate(moveDate(date,1))}><Icon name="right" size={16}/></button>{date&&date!==today&&<button className="button" onClick={()=>changeDate(today)}>오늘</button>}<button className="button icon" onClick={()=>void feed.refresh(true)} disabled={feed.refreshing||!date} aria-label="데이터 새로고침" title="데이터 새로고침"><Icon name="refresh" className={feed.refreshing?"spin":""}/></button><button className="button command-center-launch" onClick={()=>{setHoverMinute(null);setModal("command");}}><Icon name="grid" size={16}/>Command Center</button><button className="button" onClick={()=>{setHoverMinute(null);setModal("board");}}><Icon name="grid" size={16}/>차트 전체보기</button><button className="button primary" onClick={exportDay} disabled={!rows.length}><Icon name="download" size={16}/><span>내보내기</span></button></div>}
      </div>
      {feed.error&&<div className="notice" role="alert"><Icon name="warning"/><span>{feed.error}{rows.length>0?" 마지막으로 조회한 기록을 유지하고 있어요.":""}</span><button className="button small" onClick={()=>void feed.refresh(true)} disabled={feed.refreshing}>다시 시도</button></div>}
      {!feed.error&&feed.warning&&<div className="notice" role="status"><Icon name="warning"/><span>{feed.warning}</span></div>}
      {!feed.error&&!feed.warning&&!feed.loading&&status.tone==="warn"&&<div className="notice" role="status"><Icon name="clock"/><span>{status.detail} · {sourceLabel(last?.flowSource)} · {breadthLabel(last?.breadthSource)}</span></div>}
      {mode==="daily"&&<div className="toolbar" style={{marginBottom:16}}><Link className="button small" href={"/research?date="+date}>섹터 · 날짜 비교 · 기간 성과 · 메모 검색</Link></div>}
      {mode==="overview"?<div className="overview-metric-row">
        <div className="overview-metrics-source"><Metrics rows={rows} loading={feed.loading}/></div>
        <section className="metric overview-pulse-metric" id="market-pulse" aria-label="Market Pulse 2.0">
          <div className="overview-pulse-gauge-side">
            <div className="metric-label"><span>Market Pulse <small>2.0</small></span></div>
            <svg className="overview-pulse-gauge" viewBox="0 0 130 78" role={pulse.score==null?undefined:"meter"} aria-valuemin={pulse.score==null?undefined:0} aria-valuemax={pulse.score==null?undefined:100} aria-valuenow={pulse.score??undefined}>
              <defs><linearGradient id="overview-pulse-arc" x1="10" y1="0" x2="120" y2="0"><stop stopColor="#d8a94b"/><stop offset=".55" stopColor="#f1cf77"/><stop offset="1" stopColor="#9a712d"/></linearGradient></defs>
              <path d="M17 61 A48 48 0 0 1 113 61" stroke="#2a2822" strokeWidth="10" strokeLinecap="round" fill="none"/>
              <path d="M17 61 A48 48 0 0 1 113 61" stroke="url(#overview-pulse-arc)" strokeWidth="10" strokeLinecap="round" fill="none" opacity={pulse.score==null?.28:.95}/>
              {pulse.score!=null&&<circle cx={pulseMiniX} cy={pulseMiniY} r="4.8" fill="#f6e8bf" stroke="#0b0a08" strokeWidth="2"/>}
              <text x="65" y="53" textAnchor="middle" className="overview-pulse-score">{pulse.score??"—"}</text>
              <text x="65" y="72" textAnchor="middle" className="overview-pulse-regime-text">{pulse.regime}</text>
            </svg>
          </div>
          <div className="overview-pulse-factor-list">
            {pulse.factors.slice(0,5).map((factor,index)=><div key={factor.name}><span>{pulseMiniLabels[index]??factor.name}</span><strong className="num">{factor.value==null?"—":Math.round(50+factor.value*50)}</strong></div>)}
          </div>
        </section>
      </div>:<Metrics rows={rows} loading={feed.loading}/>} 
      {mode==="overview"? <>
        <div className="dashboard-grid overview-dashboard-grid">
          <div className="main-column">{mainChartPanel()}</div>
          <aside className="overview-flow-column" aria-label="투자주체 누적 수급">
            <section className="panel overview-flow-chart">
              <div className="panel-header"><div><h2 className="panel-title">투자주체별 누적 수급</h2><p className="panel-subtitle">{last?last.time+" 기준":"기록 대기"} · 억원</p></div><button className="button icon small" onClick={()=>openChart("flow")} aria-label="수급 차트 크게 보기" disabled={!rows.length}><Icon name="expand" size={15}/></button></div>
              <div className="overview-flow-values"><span><i className="flow-blue"/>외국인 <strong className="num flow-blue">{formatNumber(last?.foreignFlow,0,true)}</strong></span><span><i className="flow-red"/>기관 <strong className="num flow-red">{formatNumber(last?.instFlow,0,true)}</strong></span><span><i className="flow-yellow"/>개인 <strong className="num flow-yellow">{formatNumber(last?.indivFlow,0,true)}</strong></span></div>
              {feed.loading?<div className="chart-loading compact">시장 기록을 불러오는 중</div>:!rows.length?<div className="empty-state compact">수급 기록이 없습니다.</div>:<MarketChart {...chartProps} kind="flow" compact syncGroup="balta-overview-flow" onExpand={()=>openChart("flow")}/>} 
            </section>
          </aside>
        </div>
        <section className="overview-summary-grid" aria-label="시장 핵심 요약">
          <section className="panel overview-summary-card overview-live-card">
            <div className="panel-header"><div><h2 className="panel-title">실시간 주요 지표</h2><p className="panel-subtitle">{last?last.time+" 기준":"기록 대기"} · 실제 수집 데이터</p></div><Link className="overview-summary-link" href={"/daily?date="+date}>상세 보기 <Icon name="right" size={12}/></Link></div>
            <div className="overview-live-table">{overviewStats.map(item=><div className="overview-live-row" key={item.label}><span>{item.label}</span><strong className={"num "+item.tone}>{formatNumber(item.value,0,item.signed)}{item.value!=null&&<small>{item.unit}</small>}</strong></div>)}</div>
            <div className="overview-live-foot"><span>{last?sourceLabel(last.flowSource):"수급 기록 대기"}</span><span>{last?breadthLabel(last.breadthSource):"시장폭 기록 대기"}</span></div>
          </section>
          <MarketMovers/>
          <div className="overview-summary-card overview-signal-card"><SignalPanel events={events} onSelect={focusMinute} onAll={showRecords}/></div>
        </section>
      </>:<>
        <div className="dashboard-grid"><div className="main-column">
          <PanelLayout scope={mode} items={[
            {id:"main-chart",title:"장중 흐름",content:mainChartPanel()},
            ...[...overviewKinds,...comparisonKinds].map(key=>({id:"chart-"+key,title:chartLabels[key]+" 차트",content:settings.compare&&rows.length>0&&key!==kind?comparisonChart(key):<p className="panel-subtitle">비교 차트 설정이 꺼져 있거나 현재 주 차트와 같은 지표입니다.</p>})),
            {id:"summary",title:"일별 요약",content:<SessionSummary rows={signalRows} events={events}/>},
            {id:"report",title:"동시간대 비교 · 리포트",content:<ComparisonReport rows={signalRows} events={events} date={date}/>},
            {id:"diagnostics",title:"시장 모니터",content:<Diagnostics rows={rows} events={events} date={date} now={now} error={feed.error||feed.warning} loading={feed.loading} onSelect={focusMinute}/>},
            {id:"records",title:"기록 탐색",content:<RecordsPanel rows={rows} events={events} date={date} selectedMinute={selectedMinute} onSelect={focusMinute} view={tableView} onViewChange={setTableView}/>} 
          ]}/>
        </div><aside className="insight-column" aria-label="시장 요약"><PanelLayout scope={mode+"-aside"} items={[{id:"brief",title:"시장 브리핑",content:<div id="market-pulse"><MarketPulsePanel pulse={pulse} sectorStatus={sectorStatus} warning={feed.error || feed.warning || (status.tone === "warn" ? status.label : "")}/></div>},{id:"flows",title:"투자자 수급",content:<FlowPanel row={last}/>},{id:"signals",title:"최근 신호",content:<SignalPanel events={events} onSelect={focusMinute} onAll={showRecords}/>}]} /></aside></div>
      </>}
      {mode==="overview"&&<section className="mockup-shortcuts" aria-label="빠른 메뉴">
        <Link href="/history" className="mockup-shortcut-card calendar"><span className="mockup-shortcut-icon"><Icon name="calendar" size={26}/></span><div><strong>시장 캘린더</strong><p>과거를 보면 오늘이 보입니다.</p></div><Icon name="right" size={16}/></Link>
        <Link href={"/research?date="+date} className="mockup-shortcut-card sector"><span className="mockup-shortcut-icon"><Icon name="layers" size={26}/></span><div><strong>섹터 분석</strong><p>지금 시장을 이끄는 주도 섹터는?</p></div><Icon name="right" size={16}/></Link>
        <Link href={"/research?date="+date} className="mockup-shortcut-card scanner"><span className="mockup-shortcut-icon"><Icon name="search" size={26}/></span><div><strong>종목 스캐너</strong><p>기회는 늘 움직이고 있습니다.</p></div><Icon name="right" size={16}/></Link>
        <button className="mockup-shortcut-card charts" onClick={()=>{setHoverMinute(null);setModal("board");}}><span className="mockup-shortcut-icon"><Icon name="chart" size={26}/></span><div><strong>차트 전체보기</strong><p>더 넓은 시야로 시장을 바라보세요.</p></div><Icon name="right" size={16}/></button>
      </section>}
      {mode==="daily"&&<section className="balta-library" aria-labelledby="balta-library-title">
        <div className="balta-library-heading">
          <div><span>THE BALTA ARCHIVE</span><h2 id="balta-library-title">발타의 서재</h2><p>시장을 읽은 뒤, 다시 원칙으로 돌아가는 공간입니다.</p></div>
          <div className="balta-library-mantra"><span aria-hidden="true">原則</span><strong>시장을 읽고,<br/>원칙으로 돌아간다.</strong></div>
        </div>
        <div className="balta-library-grid">
          <a className="balta-library-card balta-library-card-gyeong" href="/baltagyeong.html">
            <div className="balta-library-icon"><Icon name="book" size={24}/></div>
            <div><span className="balta-library-kicker">BALTA GYEONG · MARKET PRINCIPLES</span><h3>발타경</h3><p>발타의 투자 원칙과 시장관을 한곳에서 읽습니다.</p><span className="balta-library-read">발타경 읽기 <Icon name="right" size={12}/></span></div>
            <span className="balta-library-card-number" aria-hidden="true">經</span>
          </a>
          <Link className="balta-library-card balta-library-card-jungyong" href="/balta-jungyong">
            <div className="balta-library-icon"><Icon name="balance" size={24}/></div>
            <div><span className="balta-library-kicker">BALTA JUNGYONG · 33 CHAPTERS</span><h3>발타 중용</h3><p>서른세 장의 문장으로 투자와 시장의 균형을 돌아봅니다.</p><span className="balta-library-read">33장 읽기 <Icon name="right" size={12}/></span></div>
            <span className="balta-library-card-number" aria-hidden="true">中</span>
          </Link>
        </div>
        <div className="balta-library-foot"><span><Icon name="book" size={12}/> 발타경 · 시장 원칙과 기록</span><span><Icon name="balance" size={12}/> 발타 중용 · 33장</span><span>DATA → PRINCIPLE → DECISION</span></div>
      </section>}
      {mode==="overview"&&<footer className="workspace-footer overview-reference-footer">
        <div className="workspace-footer-status"><Brand/><span>GOOD DATA. BETTER DECISIONS.</span></div>
        <nav className="overview-footer-links"><a href="/baltagyeong.html">발타경</a><Link href="/balta-jungyong">발타 중용</Link><Link href="/disclaimer">책임면책고지</Link><Link href="/research">문의하기</Link></nav>
      </footer>}
      <InvestmentDisclaimer/>
      {mode!=="overview"&&<footer className="workspace-footer">
        <div className="workspace-footer-status"><Icon name="clock" size={13}/><span>{feed.fetchedAt?"마지막 조회 "+feed.fetchedAt:"조회 대기"} · {last?"데이터 "+last.time+" 기준":"저장 기록 없음"} · KST</span></div>
        <div className="workspace-footer-brand"><strong>© 2026 BALTATOOL</strong><span>Market Intelligence Terminal</span></div>
        <div className="workspace-footer-actions"><span>{date&&date===today?(settings.autoRefresh?"60초 자동 갱신":"자동 갱신 일시정지"):"과거 기록 조회"}</span><button className="footer-text-button" onClick={()=>setModal("guide")}>지표 읽는 법</button><Link className="footer-legal-link" href="/disclaimer">투자 정보 이용 안내</Link></div>
      </footer>}
    </main>
    <nav className="mobile-nav" aria-label="모바일 메뉴"><Link href="/" className={mode==="overview"?"active":""} aria-current={mode==="overview"?"page":undefined}><Icon name="grid"/><span>대시보드</span></Link><Link href="/daily" className={mode==="daily"?"active":""} aria-current={mode==="daily"?"page":undefined}><Icon name="chart"/><span>일별</span></Link><Link href="/history"><Icon name="calendar"/><span>캘린더</span></Link><Link href="/research"><Icon name="search"/><span>리서치</span></Link><button onClick={()=>setModal("more")}><Icon name="layers"/><span>더보기</span></button></nav>
    <Modal open={modal==="more"} onClose={()=>setModal(null)} title="발타툴 메뉴"><div className="mobile-more-menu">
      <div className="mobile-more-brand"><Brand/><span>시장을 읽고, 원칙으로 돌아갑니다.</span></div>
      <div className="mobile-more-grid"><Link href={"/replay?date="+date} onClick={()=>setModal(null)}><Icon name="chart"/><span><strong>시장 복기</strong><small>선택 날짜의 흐름 다시 보기</small></span></Link><a href="/baltagyeong.html"><Icon name="book"/><span><strong>발타경</strong><small>발타의 시장 원칙</small></span></a><Link href="/balta-jungyong" onClick={()=>setModal(null)}><Icon name="balance"/><span><strong>발타 중용</strong><small>33장으로 읽는 투자와 시장</small></span></Link><button onClick={()=>setModal("guide")}><Icon name="help"/><span><strong>지표 가이드</strong><small>데이터와 신호 읽는 법</small></span></button><button onClick={()=>setModal("settings")}><Icon name="settings"/><span><strong>화면 설정</strong><small>차트와 알림 설정</small></span></button><Link href="/disclaimer" onClick={()=>setModal(null)}><Icon name="shield"/><span><strong>책임면책고지</strong><small>투자 정보 이용 안내</small></span></Link></div>
    </div></Modal>
    <Modal open={modal==="settings"} onClose={()=>setModal(null)} title="화면 설정"><div className="modal-content">
      {([{key:"autoRefresh",title:"자동 갱신",text:"오늘 기록을 60초마다 갱신합니다. 숨겨진 탭에서는 잠시 쉽니다."},{key:"compare",title:"비교 차트",text:"시장 폭·비율과 개별 지수 차트를 함께 확인합니다."},{key:"markers",title:"차트 신호 표시",text:"시장폭·수급·지수 차트에 강한 신호와 자동 감지 변곡점을 표시합니다."},{key:"autoScale",title:"세로축 자동 조절",text:"끄면 시장 폭·수급 차트를 0 중심의 대칭 범위로 표시합니다."}] as const).map(item=><label className="settings-row" key={item.key}><span><strong>{item.title}</strong><p>{item.text}</p></span><input className="switch" type="checkbox" checked={settings[item.key]} onChange={e=>setSettings(old=>({...old,[item.key]:e.target.checked}))}/></label>)}
      <label className="settings-row"><span><strong>새 강한 신호 알림</strong><p>화면 갱신 중 새로 감지한 강한 신호만 알립니다. 과거 기록에는 알리지 않습니다.</p></span><input className="switch" type="checkbox" checked={settings.notifications} onChange={e=>void toggleNotifications(e.target.checked)}/></label><div className="settings-row"><span><strong>설정 저장</strong><p>선택한 화면 설정은 이 브라우저에 저장됩니다.</p></span><button className="button small" onClick={()=>setSettings(defaults)}>초기화</button></div><div className="toolbar" style={{marginTop:20,justifyContent:"space-between"}}><button className="button" onClick={()=>setModal("guide")}><Icon name="help" size={16}/>지표 가이드</button><button className="button ghost" onClick={logout} disabled={loggingOut}><Icon name="logout" size={16}/>로그아웃</button></div>
    </div></Modal>
    <Modal open={modal==="guide"} onClose={()=>setModal(null)} title="지표 읽는 법"><div className="modal-content">{[
      ["시장 폭과 시장점수","시장 폭은 상승 종목 수에서 하락 종목 수를 뺀 값입니다. 시장점수는 기존 계산식을 사용해 −100부터 +100까지 표시합니다."],
      ["지수 등락 기준","상단 KOSPI·KOSDAQ 등락률은 직전 기록과의 비교입니다. 전일 종가 대비 수치가 아닙니다. 지수 차트는 왼쪽 축 KOSPI, 오른쪽 축 KOSDAQ을 사용합니다."],
      ["투자자 수급","외국인·기관·개인 순매수는 모두 억원 단위입니다. 양수는 순매수, 음수는 순매도입니다. 수급을 받지 못한 값은 대시(—)로 표시합니다."],
      ["직전값과 누락 구간","직전 수급 유지로 표시된 값은 새로 받은 수급이 아닙니다. 없는 시간대는 차트를 끊어 표시하며, 기록을 보간해 만들지 않습니다."],
      ["수집 신호와 차트 분석","수집 신호는 서버에 저장된 신호, 차트 분석은 기존 일별 분석 규칙으로 기록에서 계산한 신호입니다. 시장폭 급반전, 외국인·기관 수급 전환, 지수·수급 다이버전스, 장중 고점·저점 전환도 변곡점 신호로 기록합니다. 같은 종류의 반복 신호는 10분 간격으로 정리합니다."],
      ["조건 충족률","기존의 신뢰도 %를 조건 충족률로 바꿨습니다. 여러 조건 중 충족한 비율이며, 상승 확률이나 수익 확률을 뜻하지 않습니다."],
      ["차트와 기록 탐색","차트 상단 수치는 최신 수신 기록입니다. 커서를 올리면 해당 시각의 값이 별도로 표시됩니다. 외인은 파랑, 기관은 빨강, 개인은 노랑으로 구분합니다. 수급 부호는 순매수·순매도를 뜻합니다."],
      ["확대와 구간 탐색","+/− 버튼, Ctrl/⌘+휠, 구간 드래그로 5분까지 확대합니다. 이동 모드에서는 끌어서 시간대를 이동할 수 있습니다. 하단 탐색 막대나 시작·끝 슬라이더를 사용해도 됩니다. 더블클릭·전체 버튼으로 초기화하고, 최근 1시간 버튼으로 최신 구간을 따라갑니다. 확대 아이콘은 큰 차트 창을 엽니다. 모든 차트의 시간 범위가 함께 변경됩니다."],
      ["CSV 다운로드","상단 내보내기는 선택 날짜의 전체 지표를 저장합니다. 기록 탐색의 CSV는 현재 검색·강도 필터와 정렬을 반영합니다."]
    ].map(([title,text])=><div className="guide-item" key={title}><strong>{title}</strong><p>{text}</p></div>)}</div></Modal>
    <Modal open={modal==="command"} onClose={()=>setModal(null)} title={"Command Center · "+date} full>
      <div className="command-center-shell">
        <div className="command-center-toolbar">
          <div className="command-center-title"><strong>KR Market Command Center</strong><span className="panel-subtitle">{last ? ((last.session==="KRX_AFTER_MARKET"?"애프터마켓":last.session==="REGULAR"?"정규장":"현재 세션")+" · "+last.time+" 기준") : "데이터 대기"}</span></div>
          <div className="toolbar">{ranges()}<button className="button small" onClick={()=>void feed.refresh(true)} disabled={feed.refreshing||!date}><Icon name="refresh" className={feed.refreshing?"spin":""} size={14}/>새로고침</button><button className="button small" onClick={()=>setModal("board")}><Icon name="expand" size={14}/>차트 보드</button></div>
        </div>
        <Metrics rows={rows} loading={feed.loading}/>
        <div className="command-center-grid">
          <div className="command-center-charts">
            {(["flow","breadth","kospi","kosdaq"] as ChartKind[]).map(key=><section className="panel command-chart" key={key}><div className="panel-header"><h3 className="panel-title">{chartLabels[key]}</h3><button className="button icon small" aria-label={chartLabels[key]+" 크게 보기"} onClick={()=>openChart(key)}><Icon name="expand" size={14}/></button></div>{feed.loading?<div className="chart-loading">시장 기록을 불러오는 중</div>:!rows.length?<div className="empty-state compact">기록 없음</div>:<MarketChart {...chartProps} kind={key} compact syncGroup="balta-command" onExpand={()=>openChart(key)}/>}</section>)}
          </div>
          <div className="command-center-heatmap"><SectorHeatmap dateOverride={date} compact/></div>
          <aside className="command-center-insights" aria-label="Command Center 시장 요약"><MarketPulsePanel pulse={pulse} sectorStatus={sectorStatus} warning={feed.error || feed.warning || (status.tone === "warn" ? status.label : "")}/><FlowPanel row={last}/><SignalPanel events={events} onSelect={minute=>{setModal(null);focusMinute(minute);}} onAll={()=>{setModal(null);showRecords();}}/></aside>
        </div>
      </div>
    </Modal>
    <Modal open={modal==="board"} onClose={()=>setModal(null)} title={"차트 전체보기 · "+date} full>
      <div className="chart-board-toolbar"><div className="toolbar">{ranges()}<button className="button small" onClick={resetCharts}>확대 초기화</button></div><div className="segmented" aria-label="전체보기 열 수">{([2,3] as const).map(n=><button key={n} aria-pressed={boardColumns===n} className={boardColumns===n?"active":""} onClick={()=>setBoardColumns(n)}>{n}열</button>)}</div><span className="panel-subtitle">시간 범위·커서 연동 · 모바일은 1열 · Esc로 닫기</span></div>
      {feed.loading?<div className="chart-loading">시장 기록을 불러오는 중</div>:!rows.length?<div className="empty-state"><strong>{feed.error||"선택한 날짜의 기록이 없습니다."}</strong><button className="button" onClick={()=>void feed.refresh(true)}>다시 조회</button></div>:<div className={"chart-board-grid columns-"+boardColumns}>{(["flow","breadth","ratio","kospi","kosdaq","score","index","accel"] as ChartKind[]).map(key=><section className="panel" key={key}><div className="panel-header"><h3 className="panel-title">{chartLabels[key]}</h3><button className="button icon small" aria-label={chartLabels[key]+" 크게 보기"} onClick={()=>openChart(key)}><Icon name="expand" size={14}/></button></div><MarketChart {...chartProps} kind={key} compact syncGroup="balta-board" onExpand={()=>openChart(key)}/></section>)}</div>}
    </Modal>
    <Modal open={modal==="chart"} onClose={()=>{setModal(returnToModal);setReturnToModal(null);}} title={chartLabels[expandedKind]+" · "+date} wide><div className="panel-header"><div className="chart-legend"><span className="panel-subtitle">연결된 시간 범위</span><strong className="num" style={{fontSize:14}}>{minuteLabel(domain[0])}–{minuteLabel(domain[1])}</strong></div>{ranges()}</div><MarketChart {...chartProps} kind={expandedKind} syncGroup="balta-fullscreen"/><div className="chart-footer"><span>Ctrl/⌘ + 휠 확대 · Esc로 닫기</span><button className="button small" onClick={()=>{setRange("all");setSelectedMinute(null);}}>전체 구간</button></div></Modal>
    {toast&&<div className="toast" role="status"><Icon name="check" size={16}/><span>{toast}</span><button className="button ghost small icon" onClick={()=>setToast("")} aria-label="메시지 닫기"><Icon name="close" size={14}/></button></div>}
  </div>;
}
